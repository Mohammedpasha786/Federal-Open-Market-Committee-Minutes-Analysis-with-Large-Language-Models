# Federal Open Market Committee Minutes Analysis with Large Language Models

A MATLAB retrieval-augmented generation (RAG) system that answers questions about Federal Open Market Committee (FOMC) minutes. Minutes are split into passages, embedded with all-MiniLM, stored in PostgreSQL with pgvector (or in memory), retrieved by cosine similarity, and passed with the question to an LLM. A validation framework scores retrieval and answers.

Submission for the MathWorks Challenge Project Hub: *FOMC Minutes Analysis with Large Language Models*.

## Workflow

```
FOMC minutes -> clean -> passages -> all-MiniLM embeddings -> pgvector / in-memory store
question -> embedding -> top-k similar passages -> prompt -> LLM answer -> validation
```

## Repository structure

```
main.m                    single entry point (one-click run)
src/                      pipeline functions
data/sample/              sample minutes and validation questions (no download needed)
models/                   embedding cache (pretrained model installed via Add-On Explorer)
sql/schema.sql            pgvector schema
tests/FOMCPipelineTest.m  unit and end-to-end tests
docs/usage.md             configuration, PostgreSQL, LLM, and metrics guide
results/                  generated report, metrics, and figure
```

## Setup

1. MATLAB R2024a or later with the toolboxes listed below.
2. Add-On Explorer: install **Text Analytics Toolbox Model for all-MiniLM-L12-v2 Network**.
3. Optional, for LLM answers: install **Large Language Models (LLMs) with MATLAB** and set an API key (`setenv("OPENAI_API_KEY","...")`) or use Ollama.
4. Optional, for the database: PostgreSQL with pgvector (see `docs/usage.md`).

No setup beyond step 1 is needed to run the demo: without the add-on the pipeline falls back to TF-IDF vectors, without an LLM it returns the retrieved evidence, and without PostgreSQL it uses an in-memory vector store.

## Run

```matlab
main
```

This loads the bundled sample minutes, builds the vector store, answers six validation questions, writes `results/report.md`, `results/validation_metrics.csv`, and `results/validation.png`, and prints the metric summary. To use real minutes from federalreserve.gov, set `cfg.useSampleData = false` in `src/fomcConfig.m`.

## Test

```matlab
runtests("tests")
```

The end-to-end test runs offline with the TF-IDF fallback and requires a hit rate of at least 0.8 on the sample data.

## Results

Running `main` on the sample data produces:

- `results/report.md`: metrics table and an answer for each question with its top source
- `results/validation_metrics.csv`: per-question hit, reciprocal rank, keyword recall, and answer coverage
- `results/validation.png`: validation bars and top similarity scores

Expected with the bundled sample data: HitRateAtK close to 1.0 and MeanKeywordRecall close to 1.0 (with the neural embedding and with the TF-IDF fallback). Exact scores and LLM wording vary by model.

The sample minutes in `data/sample/` are synthetic text written for testing, not Federal Reserve documents.

## Dependencies

| Item | Needed for |
|---|---|
| MATLAB R2024a+ | Everything |
| Text Analytics Toolbox | Tokenization, `documentEmbedding`, HTML text extraction |
| Deep Learning Toolbox | Running the embedding network |
| Statistics and Machine Learning Toolbox | Listed by the project brief; not required by the current code path |
| Database Toolbox | PostgreSQL native interface (optional) |
| Text Analytics Toolbox Model for all-MiniLM-L12-v2 Network | Neural embeddings (optional, TF-IDF fallback otherwise) |
| Large Language Models (LLMs) with MATLAB | OpenAI or Ollama answers (optional) |
| PostgreSQL + pgvector | Persistent vector store (optional) |

## Data sources

Minutes: https://www.federalreserve.gov/monetarypolicy/fomccalendars.htm

## License

MIT, see `LICENSE`.

## Contact

MD. Afreed Pasha, SR University, Warangal. GitHub: [Mohammedpasha786](https://github.com/Mohammedpasha786)
