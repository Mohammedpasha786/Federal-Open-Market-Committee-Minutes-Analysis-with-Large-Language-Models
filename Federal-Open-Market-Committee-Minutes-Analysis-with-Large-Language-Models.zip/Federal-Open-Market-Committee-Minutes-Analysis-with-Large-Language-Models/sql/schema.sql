CREATE EXTENSION IF NOT EXISTS vector;

CREATE TABLE IF NOT EXISTS fomc_chunks (
    id SERIAL PRIMARY KEY,
    meeting TEXT,
    chunk_id INTEGER,
    content TEXT,
    embedding vector(384)
);

CREATE INDEX IF NOT EXISTS fomc_chunks_embedding_idx
    ON fomc_chunks USING hnsw (embedding vector_cosine_ops);
