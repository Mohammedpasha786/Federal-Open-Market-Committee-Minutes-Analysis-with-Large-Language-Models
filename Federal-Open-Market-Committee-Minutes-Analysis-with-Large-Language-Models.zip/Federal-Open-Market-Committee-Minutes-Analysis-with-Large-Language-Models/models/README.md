# Models

No model is trained in this project. Embeddings come from the pretrained all-MiniLM-L12-v2 network, installed
from the MATLAB Add-On Explorer ("Text Analytics Toolbox Model for all-MiniLM-L12-v2 Network") and loaded with
`documentEmbedding`.

`embeddings_cache.mat` is written here on the first run so later runs skip re-embedding. It is git-ignored.
